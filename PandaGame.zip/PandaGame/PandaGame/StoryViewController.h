//
//  StoryViewController.h
//  PandaGame
//
//  Created by Steve on 3/9/15.
//  Copyright (c) 2015 JJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StoryViewController : UIViewController<UIAlertViewDelegate>
-(void)stopPlaying;
@end
