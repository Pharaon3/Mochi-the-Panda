//
//  Game1ViewController.m
//  PandaGame
//
//  Created by Steve on 2/26/15.
//  Copyright (c) 2015 JJ. All rights reserved.
//

#import "Game1ViewController.h"
#import "Game1PlayViewController.h"
@import GoogleMobileAds;

@interface Game1ViewController()
@property (weak, nonatomic) IBOutlet UIView *mainView;
@property int level;
@end

@implementation Game1ViewController

-(void)fadeIn:(SEL)callBack
{
    [UIView animateWithDuration:2 animations:^{
        [_mainView setAlpha:0];
    } completion:^(BOOL finished) {
        [self performSelector:callBack withObject:nil afterDelay:0];
               [self performSelector:@selector(resetScreen) withObject:nil afterDelay:0.5];

    }];
}
-(void)resetScreen
{
    [_mainView setAlpha:1];
}
-(void)goHomeScreen
{
    [self.navigationController popViewControllerAnimated:NO];
}
- (IBAction)onBack:(id)sender {
    [self fadeIn:@selector(goHomeScreen)];
}
-(void)onPlayGame
{
    Game1PlayViewController* vc = (Game1PlayViewController*)[self.storyboard instantiateViewControllerWithIdentifier:@"Game1PlayViewController"];
    
    vc.level = _level;
    [self.navigationController pushViewController:vc animated:NO];

}
- (IBAction)onPlay:(id)sender {
    _level = (int)((UIButton*)sender).tag;

    switch (_level)
    {
        case 10:
        case 20:
        case 30:
        {
            [self fadeIn:@selector(onPlayGame)];
        }
            break;
    }
}
-(void)viewDidLoad
{
    GADBannerView* gadBannerView = [[GADBannerView alloc]initWithFrame:CGRectMake(0, 700, 1024, 68)];
    [self.mainView addSubview:gadBannerView];
    
    gadBannerView.adUnitID = @"ca-app-pub-8387890899538086/9502167851";
    gadBannerView.rootViewController = self;
    [gadBannerView loadRequest:[GADRequest request]];
}
@end
