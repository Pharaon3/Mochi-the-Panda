//
//  MemoryGameViewController.m
//  PandaGame
//
//  Created by Steve on 2/9/15.
//  Copyright (c) 2015 JJ. All rights reserved.
//

#import "MemoryGameViewController.h"


@interface MemoryGameViewController ()


@end

@implementation MemoryGameViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    NSArray* arrList = @[@"i_placeholder_match.png", @"i_placeholder_memory.png", @"i_placeholder_spell.png", @"i_placeholder_story.png", @"i_placeholder_upgrade.png"];
    [_bkgView setImage:[UIImage imageNamed:arrList[_index]]];
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleSingleTap:)];
    self.bkgView.userInteractionEnabled = YES;
    [self.bkgView addGestureRecognizer:singleTap];
    
}

-(void)handleSingleTap:(id)sender
{
    [UIView animateWithDuration:1.5 animations:^{
        self.bkgView.alpha = 0;
    } completion:^(BOOL finished) {
            [self.navigationController popViewControllerAnimated:NO];
    }];

}
@end
