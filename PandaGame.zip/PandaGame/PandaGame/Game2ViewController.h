//
//  Game2ViewController.h
//  PandaGame
//
//  Created by Steve on 3/11/15.
//  Copyright (c) 2015 JJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Game2ViewController : UIViewController

@end
